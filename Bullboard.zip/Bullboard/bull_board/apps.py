from django.apps import AppConfig


class BullBoardConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'bull_board'
